# MyGamingStreams

A Chrome extension to help gaming fans to track their favorites streamers from Twitch, Azubu and others stream services.
------------------------------------------------------------------------
It's pretty boring to keep checking if your favorite streammer is online, isn't it? Thinking on it, i've created a Chrome extension to fans check their favorite streammers status with one click.

![enter image description here](https://4.bp.blogspot.com/--ogsK-MV__8/VuZBhKtML8I/AAAAAAAAppc/1gg6is1WUgIBCx9ifAEI3kpTJdjTIK-1g/s1600/status.jpg)

The apps uses Azubu and Twitch api to check it's status. Basically, it's an Ajax method that checks if each streammer is online when the app is open, when the user clicks on refresh button or every minute.

The user can also add a new streammer to his list. It's stored on localStorage crom Chrome.